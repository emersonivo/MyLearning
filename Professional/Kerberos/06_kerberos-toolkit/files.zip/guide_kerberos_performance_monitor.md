# Guia: `kerberos_performance_monitor.py`

## Visão Geral

Monitor de performance e detector de anomalias para KDC Kerberos. Coleta métricas de autenticação (AS-REQ, TGS-REQ), sistema (CPU, memória, disco, rede) e processo KDC em ciclos configuráveis. Armazena métricas em SQLite, estabelece uma baseline estatística de comportamento normal e detecta desvios. Opcionalmente envia as anomalias para a API do Claude (Anthropic) para análise de causa raiz em linguagem natural.

---

## Dataclass: `KDCMetrics`

Estrutura de dados que representa um snapshot de métricas do KDC. Contém:
- **Autenticação:** contagens de AS-REQ e TGS-REQ (total, sucesso, falha)
- **Performance:** tempo médio de resposta, P95 e P99 em ms
- **Sistema:** CPU%, memória%, I/O de disco e rede
- **Processo KDC:** CPU%, memória em MB, threads, arquivos abertos, conexões ativas
- **Erros:** error rate (%) e contagem de timeouts

---

## Dataclass: `PerformanceAnomaly`

Estrutura que representa uma anomalia detectada. Contém: timestamp, severity (`LOW/MEDIUM/HIGH/CRITICAL`), nome da métrica, valor atual, valor da baseline, desvio percentual, descrição legível, causas possíveis e ações recomendadas.

---

## Classe: `MetricsCollector`

### `__init__(kdc_host, kdc_port)`
Inicializa o coletor, chama `_find_kdc_process()` e prepara um deque de `response_times` (máximo 1000 amostras).

### `_find_kdc_process() → Optional[psutil.Process]`
**O que faz:** Itera sobre todos os processos do sistema via `psutil.process_iter()` procurando por `krb5kdc` no nome ou cmdline. Retorna o objeto `Process` se encontrado; `None` caso contrário (monitoramento continuará em modo system-wide).

### `collect() → KDCMetrics`
**O que faz:** Função central de coleta. Executa em sequência:
1. `_parse_kdc_logs()` para métricas de autenticação
2. `psutil` para métricas de sistema (CPU, memória, disco I/O, rede)
3. Métricas do processo KDC (se encontrado): CPU, memória RSS, threads, arquivos abertos, conexões
4. Cálculo de P50/P95/P99 a partir do deque de `response_times`
5. Cálculo do error rate

**Output:** Instância populada de `KDCMetrics`.

### `_parse_kdc_logs() → Dict[str, int]`
**O que faz:** Lê as últimas 1000 linhas de `/var/log/krb5kdc.log` (ou localização alternativa). Conta eventos AS-REQ (sucesso: `ISSUE/PROCESS`; falha: `PREAUTH_FAILED/C_PRINCIPAL_UNKNOWN`), TGS-REQ (sucesso: `ISSUE`; falha: `FAILED`) e timeouts nos últimos 60 segundos.

**Output:** Dicionário com contadores de cada tipo de evento.

### `measure_response_time() → float`
**O que faz:** Mede o tempo de resposta do KDC executando `kinit -n test@<host>` (requisição que falhará mas força round-trip ao KDC) e registra o tempo em ms no deque `response_times`.

**Output:** Tempo de resposta em ms (5000.0 em caso de timeout).

---

## Classe: `BaselineEstablisher`

### `__init__(db_path)`
Inicializa a conexão SQLite e chama `_init_db()`.

### `_init_db()`
**O que faz:** Cria (se não existir) a tabela `metrics` no SQLite com colunas para timestamp e as principais métricas de performance e sistema.

### `store_metrics(metrics)`
**O que faz:** Persiste um snapshot de `KDCMetrics` na tabela SQLite via `INSERT OR REPLACE`.

### `calculate_baseline(hours) → Dict[str, Dict[str, float]]`
**O que faz:** Consulta o SQLite com `AVG()` e `STDEV()` para cada métrica nas últimas `hours` horas. Para cada métrica calcula: média, desvio padrão, threshold superior (média + 2σ) e inferior (max(0, média - 2σ)).

**Output:** Dicionário aninhado `{metric_name: {mean, stddev, upper_threshold, lower_threshold}}`. Retorna `{}` se não houver dados suficientes.

---

## Classe: `AnomalyDetector`

### `__init__(baseline)`
Inicializa com a baseline calculada e define thresholds absolutos críticos (ex: CPU > 90%, error rate > 10%, resposta > 1000ms).

### `detect_anomalies(metrics) → List[PerformanceAnomaly]`
**O que faz:** Para cada métrica na baseline, compara o valor atual com o intervalo (mean ± 2σ). Se fora do intervalo, calcula desvio percentual e chama `_calculate_severity()`. Adicionalmente verifica thresholds absolutos críticos independentemente da baseline. Retorna lista de anomalias sem duplicatas.

### `_calculate_severity(metric_name, current_value, deviation) → str`
**O que faz:** Classifica a severidade com base no desvio percentual e na prioridade da métrica: desvio > 200% → `CRITICAL/HIGH`; > 100% → `HIGH/MEDIUM`; > 50% → `MEDIUM`; > 25% → `LOW`; abaixo → `IGNORE`.

### `_generate_description(metric_name, current, baseline) → str`
Gera string legível descrevendo o desvio em percentual com valores atual e baseline.

### `_identify_causes(metric_name, current_value) → List[str]`
**O que faz:** Retorna lista de causas prováveis pré-definidas por métrica. Ex: `as_req_count` alto → brute force em progresso, spike de autenticação legítimo ou sistema automatizado.

### `_recommend_actions(metric_name, current_value) → List[str]`
**O que faz:** Retorna lista de ações recomendadas pré-definidas por métrica. Ex: `error_rate` alto → revisar tentativas falhas, verificar configuração de clientes, checar NTP.

---

## Classe: `PerformanceMonitor`

Orquestrador principal do sistema de monitoramento.

### `__init__(kdc_host, interval, baseline_hours, output_dir, use_ai, api_key)`
**O que faz:** Instancia `MetricsCollector`, `BaselineEstablisher` e `AnomalyDetector`. Se `use_ai=True`, instancia o cliente `anthropic.Anthropic`.

### `run_once()`
**O que faz:** Executa um único ciclo de monitoramento: coleta métricas, persiste no SQLite, detecta anomalias, exibe no terminal e, se anomalias encontradas, aciona análise AI (se habilitada) e salva em arquivo JSON.

**Output:** Tupla `(metrics, anomalies)`.

### `run_continuous()`
**O que faz:** Loop infinito de monitoramento. A cada `interval` segundos executa `run_once()`. A cada 60 ciclos recalcula a baseline. Exibe cabeçalho inicial com configuração. Para com `Ctrl+C`.

### `_display_metrics(metrics)`
**O que faz:** Formata e imprime no terminal as métricas atuais agrupadas por categoria (Autenticação, Performance, Sistema).

### `_display_anomaly(anomaly)`
**O que faz:** Exibe detalhes de uma anomalia com cor correspondente à severidade (vermelho=CRITICAL/HIGH, amarelo=MEDIUM, ciano=LOW), incluindo 2 causas e 2 ações recomendadas.

### `_ai_analyze_anomalies(anomalies, metrics) → Dict`
**O que faz:** Serializa as anomalias e métricas atuais em JSON e envia para `claude-sonnet-4-20250514` via API Anthropic solicitando: análise de causa raiz, correlação entre anomalias, avaliação de risco, prioridade de investigação e plano de remediação. Tenta parsear a resposta como JSON.

**Output:** Dicionário com a análise estruturada ou `{'raw_response': ...}` se o parse falhar.

### `_display_ai_analysis(analysis)`
**O que faz:** Exibe o resultado da análise AI com campos `root_cause`, `risk_assessment` e `priority`.

### `_save_anomalies(anomalies, metrics)`
**O que faz:** Persiste as anomalias detectadas e o snapshot de métricas em arquivo JSON no diretório de output.

**Output:** `anomalies_<timestamp>.json`

---

## Função: `main()`

**O que faz:** Processa argumentos CLI, instancia `PerformanceMonitor` e chama `run_once()` ou `run_continuous()`.

**Argumentos CLI:**

| Flag | Descrição | Padrão |
|---|---|---|
| `--kdc` | Host ou IP do KDC | `localhost` |
| `--interval` | Intervalo entre ciclos (s) | 60 |
| `--baseline-hours` | Horas de dados para baseline | 24 |
| `--output-dir` | Diretório de saída | `performance_monitoring/` |
| `--once` | Executa um ciclo e encerra | desativado |
| `--ai` | Ativa análise via Claude API | desativado |
| `--api-key` | Chave da API Anthropic | nenhuma |

---

## Output Geral do Script

| Arquivo | Formato | Conteúdo |
|---|---|---|
| `metrics.db` | SQLite | Histórico de métricas para cálculo de baseline |
| `anomalies_<ts>.json` | JSON | Snapshot de métricas + lista de anomalias detectadas |

O terminal exibe métricas formatadas a cada ciclo e anomalias coloridas por severidade com causas e recomendações. Com `--ai`, exibe análise de causa raiz gerada pelo Claude.

---

## Dependências

- `psutil` (`pip install psutil`)
- `anthropic` (`pip install anthropic`) — opcional, apenas com `--ai`
- `colorama` (`pip install colorama`)
- MIT Kerberos ou Heimdal (`kinit`) — para `measure_response_time()`
- Acesso de leitura a `/var/log/krb5kdc.log`
- Bibliotecas padrão: `sqlite3`, `statistics`, `collections`, `dataclasses`, `subprocess`, `json`
