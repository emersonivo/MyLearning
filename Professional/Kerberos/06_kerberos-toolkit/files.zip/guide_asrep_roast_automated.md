# Guia: `asrep_roast_automated.py`

## Visão Geral

Script de AS-REP Roasting automatizado. Identifica contas Kerberos que não exigem pré-autenticação (`UF_DONT_REQUIRE_PREAUTH`), captura os hashes AS-REP retornados pelo KDC, os exporta em formatos para John the Ripper e Hashcat, e opcionalmente tenta quebrá-los offline. Ao final, gera um relatório JSON com os achados e recomendações de remediação.

> **O que é AS-REP Roasting:** Quando uma conta não exige pré-autenticação, qualquer pessoa pode solicitar um AS-REP ao KDC sem fornecer senha. O KDC retorna um pacote cifrado com a chave derivada da senha do usuário. Esse hash pode ser quebrado offline sem interagir novamente com o KDC.

---

## Classe: `ASREPRoaster`

### `__init__(realm, kdc, userlist, output_dir, delay, crack, wordlist)`

**O que faz:** Inicializa o objeto com o realm e KDC alvo, cria o diretório de output, e define os atributos de controle: lista de usuários vulneráveis (`roastable_users`), dicionário de hashes capturados (`hashes`) e dicionário de senhas quebradas (`cracked`).

**Parâmetros relevantes:**
- `delay`: tempo entre verificações de usuários (padrão: 2.0s) — reduz visibilidade nos logs do KDC
- `crack`: se `True`, aciona tentativa de quebra offline após coleta
- `wordlist`: caminho para wordlist usada no cracking

---

### `enumerate_users() → List[str]`

**O que faz:** Se um arquivo de usuários foi fornecido via `--userlist`, carrega e retorna sua lista. Caso contrário, usa uma lista padrão de 14 nomes comuns em ambientes enterprise (`admin`, `administrator`, `sqlservice`, `krbtgt`, etc.).

**Output:** Lista de strings com os usernames a serem verificados.

---

### `check_asrep_roastable(username) → Optional[str]`

**O que faz:** Executa `impacket-GetNPUsers` para o usuário informado, sem fornecer senha (`-no-pass`). Analisa o output em busca da string `$krb5asrep$23$`, que indica que o hash AS-REP foi retornado. Interpreta também as mensagens de erro do KDC:
- `UF_DONT_REQUIRE_PREAUTH not set` → conta segura
- `KDC_ERR_C_PRINCIPAL_UNKNOWN` → usuário inexistente

**Output:** O hash completo como string se o usuário for vulnerável; `None` caso contrário.

---

### `save_hashes()`

**O que faz:** Persiste os hashes capturados em dois arquivos: um formatado para Hashcat e outro para John the Ripper (neste script, o formato é idêntico — `$krb5asrep$23$...` — mas os arquivos são nomeados distintamente para facilitar o uso direto com cada ferramenta).

**Output:**
- `asrep_hashes_hashcat_<timestamp>.txt`
- `asrep_hashes_john_<timestamp>.txt`

---

### `crack_hashes(hashfile)`

**O que faz:** Tenta quebrar os hashes em dois estágios:

1. **John the Ripper:** executa `john --wordlist=<wordlist> <hashfile>` com timeout de 5 minutos. Em seguida executa `john --show` para exibir senhas encontradas e popula o dicionário `self.cracked`.

2. **Hashcat:** executa `hashcat -m 18200 -a 0 <hashfile> <wordlist>` (modo 18200 = AS-REP Kerberos 5). Exibe os resultados com `hashcat --show`.

Ambas as ferramentas são tentadas sequencialmente. A ausência de qualquer uma é tratada com fallback silencioso.

---

### `generate_report()`

**O que faz:** Consolida todos os achados em um relatório JSON estruturado contendo: informações do scan (realm, KDC, timestamp, total de usuários testados), sumário dos achados (usuários vulneráveis, hashes capturados, senhas quebradas), hashes truncados (80 chars), senhas quebradas e lista de recomendações de remediação.

**Output:** `asrep_report_<timestamp>.json`

---

### `run()`

**O que faz:** Orquestra o ataque completo. Enumera usuários, itera verificando cada um com `check_asrep_roastable()` (respeitando o delay), exibe sumário parcial, salva hashes se houver achados, aciona cracking se solicitado e gera o relatório final. Exibe lista final de contas vulneráveis com status de cracking.

---

## Função: `main()`

**O que faz:** Processa argumentos CLI, instancia `ASREPRoaster` e chama `run()`.

**Argumentos CLI:**

| Flag | Descrição | Padrão |
|---|---|---|
| `-r` / `--realm` | Realm Kerberos | obrigatório |
| `-k` / `--kdc` | IP do KDC | obrigatório |
| `-u` / `--userlist` | Arquivo com lista de usuários | lista padrão interna |
| `-o` / `--output-dir` | Diretório de saída | `asrep_results/` |
| `-d` / `--delay` | Delay entre verificações (s) | 2.0 |
| `--crack` | Ativa cracking offline | desativado |
| `-w` / `--wordlist` | Wordlist para cracking | nenhuma |

---

## Output Geral do Script

| Arquivo | Formato | Conteúdo |
|---|---|---|
| `asrep_hashes_hashcat_<ts>.txt` | Texto | Hashes AS-REP no formato Hashcat |
| `asrep_hashes_john_<ts>.txt` | Texto | Hashes AS-REP no formato John |
| `asrep_report_<ts>.json` | JSON | Sumário completo com achados e recomendações |

O terminal exibe o status de cada usuário verificado em tempo real, o sumário final e a lista de contas vulneráveis com suas senhas (se quebradas).

---

## Dependências

- `impacket-GetNPUsers` (`pip install impacket`)
- `john` (John the Ripper) — opcional, para cracking
- `hashcat` — opcional, para cracking
- `colorama` (`pip install colorama`)
- Bibliotecas padrão: `subprocess`, `argparse`, `json`, `time`, `hashlib`
