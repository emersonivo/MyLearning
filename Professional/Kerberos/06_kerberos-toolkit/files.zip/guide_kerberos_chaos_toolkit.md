# Guia: `kerberos_chaos_toolkit.py`

## Visão Geral

Toolkit de Chaos Engineering para infraestrutura Kerberos (KDC). Simula 8 categorias de falhas reais — memory leak, CPU exhaustion, disk fill, network latency, database contention, connection exhaustion, clock skew e degradação gradual — para testar sistemas de monitoramento, treinar resposta a incidentes e validar capacidade de detecção. **Projetado exclusivamente para uso em ambientes de lab isolados.**

---

## Classe: `SafetyCheck`

### `confirm_lab_environment()` *(método estático)*

**O que faz:** Verificação de segurança obrigatória executada antes de qualquer cenário. Obtém o hostname do sistema e aborta (`sys.exit(1)`) se o nome contiver indicadores de produção (`prod`, `production`, `live`, `corporate`, `corp`). Exige que o usuário digite manualmente `I UNDERSTAND THIS IS A LAB` para continuar.

---

## Classe: `MemoryLeakSimulator`

### `__init__(rate_mb_per_sec, max_mb)`
Configura taxa de alocação (padrão: 10 MB/s) e limite máximo (padrão: 1024 MB).

### `start()`
**O que faz:** Inicia a simulação em uma daemon thread separada. Exibe o total alocado em MB a cada segundo no terminal até `Ctrl+C` ou atingir o limite.

### `_leak_memory()`
**O que faz:** Thread interna que aloca chunks de `bytearray` proporcionais à taxa configurada a cada segundo, acumulando-os em `self.allocated_memory` (sem liberar, simulando um leak real).

### `stop()`
**O que faz:** Para a thread e libera toda a memória alocada limpando a lista, exibindo o total liberado.

---

## Classe: `CPUExhaustionSimulator`

### `__init__(num_threads, intensity)`
Configura número de threads de CPU burn (padrão: 4) e intensidade 0.0–1.0 (padrão: 0.9 = 90%).

### `start(duration)`
**O que faz:** Inicia `num_threads` threads de burn por `duration` segundos, exibindo contagem regressiva. Chama `stop()` ao concluir.

### `_burn_cpu(thread_id)`
**O que faz:** Thread interna que executa `sum(i*i for i in range(100000))` em loop contínuo. Quando `intensity < 1.0`, dorme por `(1 - intensity) * 0.01` segundos entre iterações para controlar a intensidade.

### `stop()`
Para todas as threads e exibe mensagem de conclusão.

---

## Classe: `DiskSpaceSimulator`

### `__init__(target_path, fill_mb)`
Configura path alvo (padrão: `/tmp/kdc_chaos`) e espaço a preencher (padrão: 1024 MB).

### `start()`
**O que faz:** Cria o diretório alvo e escreve arquivos de 10 MB cada contendo dados aleatórios (`os.urandom()`) até atingir o limite configurado. Exibe progresso em MB. Mantém lista dos arquivos criados para posterior limpeza.

### `cleanup()`
**O que faz:** Remove todos os arquivos criados por `start()` e tenta remover o diretório.

---

## Classe: `NetworkLatencySimulator`

### `__init__(interface, delay_ms, variance_ms)`
Configura interface de rede (padrão: `eth0`), delay em ms (padrão: 100ms) e variância (padrão: ±20ms).

### `start()`
**O que faz:** Requer root. Executa `tc qdisc add dev <interface> root netem delay <X>ms <Y>ms` para injetar latência real no kernel via traffic control. Falha graciosamente se `tc` não estiver disponível.

### `cleanup()`
**O que faz:** Remove a regra de latência com `tc qdisc del dev <interface> root`. Requer root.

---

## Classe: `DatabaseCorruptionSimulator`

### `corrupt_lightly()`
**O que faz:** Não modifica o banco de dados de fato (por segurança). Em vez disso, documenta no terminal o que ocorreria em produção (lentidão, timeouts, erros "database busy") e dispara `_concurrent_db_access()` como alternativa segura.

### `_concurrent_db_access(num_requests)`
**O que faz:** Dispara `num_requests` threads simultâneas, cada uma executando `kinit -n testuser@LAB.LOCAL`. O objetivo é saturar o KDC com requisições concorrentes, simulando lock contention no banco de dados sem corromper dados reais.

---

## Classe: `ConnectionExhaustionSimulator`

### `__init__(kdc_host, kdc_port, max_conns)`
Configura host (padrão: `localhost`), porta (padrão: 88) e máximo de conexões (padrão: 500).

### `start()`
**O que faz:** Abre conexões TCP para o KDC via `socket.connect()` em loop, mantendo-as abertas (sem enviar dados). Exibe contagem a cada 50 conexões. Para automaticamente após 50 falhas consecutivas. Os sockets abertos ficam armazenados em `self.sockets`.

### `cleanup()`
**O que faz:** Fecha todos os sockets abertos e limpa a lista.

---

## Classe: `ClockSkewSimulator`

### `__init__(skew_minutes)`
Configura desvio de tempo (padrão: 10 minutos). Kerberos rejeita tickets com clock skew > 5 minutos por padrão.

### `start()`
**O que faz:** Requer root. Salva o horário atual, calcula o novo horário somando `skew_minutes` e executa `date -s` para alterar o relógio do sistema. Exibe o antes e depois.

### `cleanup()`
**O que faz:** Restaura o horário original salvo em `start()` via `date -s`.

---

## Classe: `ResponseDegradationSimulator`

### `__init__(kdc_host)`
Configura o host KDC alvo.

### `start(duration)`
**O que faz:** Inicia thread de degradação gradual por `duration` segundos. A taxa de requisições aumenta linearmente de 1 req/s até 21 req/s ao longo da duração.

### `_gradual_degradation(duration)`
**O que faz:** A cada segundo, calcula o progresso (0–100%) e dispara um número crescente de threads, cada uma chamando `_send_request()`. Exibe carga atual e percentual de progresso.

### `_send_request()`
**O que faz:** Thread individual que executa `kinit -n user<N>@LAB.LOCAL` com usuário aleatório (1–100) e timeout de 5s. Falhas são silenciadas.

### `stop()`
Para a degradação e aguarda a thread principal.

---

## Classe: `ChaosOrchestrator`

### `list_scenarios()` *(método de classe)*
**O que faz:** Exibe no terminal a lista de todos os 8 cenários disponíveis com suas descrições.

### `run_scenario(scenario_name, **kwargs)` *(método de classe)*
**O que faz:** Localiza o simulador correspondente ao nome do cenário, instancia-o com os kwargs fornecidos, chama `start()` e, se o simulador tiver método `cleanup()`, executa a limpeza automaticamente.

---

## Função: `main()`

**O que faz:** Processa argumentos CLI, executa `SafetyCheck.confirm_lab_environment()` obrigatoriamente, e despacha para `ChaosOrchestrator.run_scenario()` com os parâmetros correspondentes ao cenário escolhido.

**Cenários e argumentos CLI:**

| Cenário | Argumentos Relevantes |
|---|---|
| `memory_leak` | `--rate-mb`, `--max-mb` |
| `cpu_exhaustion` | `--threads`, `--intensity`, `--duration` |
| `disk_fill` | `--fill-mb` |
| `network_latency` | `--interface`, `--delay-ms` *(root)* |
| `db_contention` | *(sem args extras)* |
| `connection_exhaustion` | `--kdc-host`, `--max-conns` |
| `clock_skew` | `--skew-minutes` *(root)* |
| `degradation` | `--kdc-host`, `--duration` |

---

## Output Geral do Script

O script não produz arquivos de output — toda a saída é no terminal (colorizada via `colorama`). O impacto é direto no sistema operacional e no KDC em execução. Cada simulador exibe progresso em tempo real e instrui o usuário a executar `cleanup()` quando necessário.

---

## Dependências

- `colorama` (`pip install colorama`)
- `iproute2` — para `NetworkLatencySimulator` (`apt install iproute2`)
- Privilégios root — para `NetworkLatencySimulator` e `ClockSkewSimulator`
- MIT Kerberos ou Heimdal (`kinit`) — para `DatabaseCorruptionSimulator` e `ResponseDegradationSimulator`
- Bibliotecas padrão: `subprocess`, `threading`, `time`, `os`, `socket`, `argparse`, `signal`
