# Guia: `kerb_bruteforce_advanced.py`

## Visão Geral

Script de força bruta contra autenticação Kerberos. Testa senhas contra um principal alvo (`usuario@REALM`) usando `kinit` em múltiplas threads paralelas. Ao encontrar a senha correta, extrai automaticamente o ticket e o credential cache. Todos os resultados são persistidos em JSON.

---

## Classe: `KerberosBruteForce`

Classe principal que encapsula toda a lógica do ataque.

### `__init__(realm, kdc, username, password_file, threads, delay, output_dir)`

**O que faz:** Inicializa o estado do ataque. Converte `realm` para maiúsculas, cria o diretório de output, instancia uma fila de senhas thread-safe (`queue.Queue`), um lock para controle de concorrência, e o dicionário de estatísticas (`stats`).

**Parâmetros relevantes:**
- `threads`: número de workers paralelos (padrão: 4)
- `delay`: tempo de espera entre tentativas por thread, em segundos (padrão: 1.0) — serve para evasão de rate limiting no KDC
- `output_dir`: pasta onde serão salvos os resultados

---

### `load_passwords() → List[str]`

**O que faz:** Lê o arquivo de senhas linha a linha, ignorando linhas vazias e erros de encoding. Retorna a lista de senhas brutas. Exibe contagem no terminal.

**Output:** Lista de strings com as senhas carregadas do arquivo.

---

### `generate_smart_passwords(base_passwords) → List[str]`

**O que faz:** Expande cada senha base com variações típicas de ambientes corporativos: sufixos de ano (ex: `senha2024`), combinações de estação/mês + ano (ex: `Spring2025`), sufixos especiais (`!`, `@`, `#`, `123`), versão capitalizada e versão em maiúsculas. Remove duplicatas via `set()`.

**Output:** Lista expandida de senhas candidatas, potencialmente muito maior que a lista original.

---

### `attempt_auth(password) → Dict`

**O que faz:** Tenta autenticar o principal alvo via `kinit`, passando a senha por stdin. Usa timeout de 10 segundos por tentativa. Incrementa o contador de tentativas (com lock para thread safety).

**Output:** Dicionário com chaves `success` (bool), `username`, `password`, `timestamp`, e em caso de sucesso: `principal` e `attempts`. Em caso de falha: `error` com mensagem truncada.

---

### `worker(worker_id)`

**O que faz:** Função executada por cada thread. Consome senhas da fila até a fila esvaziar ou `self.success` se tornar `True`. Para cada senha, chama `attempt_auth()`. Em caso de sucesso, seta a flag global `self.success`, imprime as credenciais encontradas e chama `extract_ticket()`. A cada 10 tentativas exibe progresso com taxa de tentativas/segundo. Respeita o `delay` configurado entre tentativas.

---

### `extract_ticket()`

**O que faz:** Após autenticação bem-sucedida, executa `klist` para capturar o estado do ticket e salva em arquivo `.txt`. Em seguida, localiza o credential cache (variável `KRB5CCNAME` ou `/tmp/krb5cc_<uid>`) e faz uma cópia do arquivo `.ccache` no diretório de output.

**Output:** Arquivo `ticket_<usuario>_<timestamp>.txt` e arquivo `krb5cc_<usuario>_<timestamp>` no diretório de output.

---

### `save_results()`

**O que faz:** Calcula a duração total do ataque, serializa alvo, configurações, estatísticas e as últimas 100 tentativas em um arquivo JSON.

**Output:** Arquivo `bruteforce_<usuario>_<timestamp>.json` com o resumo completo do ataque.

---

### `run()`

**O que faz:** Orquestra o ataque completo. Carrega senhas, gera variações se `--smart` ativo, popula a fila, dispara as threads workers, aguarda conclusão, salva resultados e exibe sumário final com total de tentativas, duração e taxa.

---

## Função: `main()`

**O que faz:** Define e processa os argumentos de linha de comando via `argparse`, instancia `KerberosBruteForce` e chama `run()`.

**Argumentos CLI:**

| Flag | Descrição | Padrão |
|---|---|---|
| `-r` / `--realm` | Realm Kerberos (ex: `LAB.LOCAL`) | obrigatório |
| `-k` / `--kdc` | IP do KDC | obrigatório |
| `-u` / `--username` | Usuário alvo | obrigatório |
| `-p` / `--password-file` | Arquivo de senhas | obrigatório |
| `-t` / `--threads` | Número de threads | 4 |
| `-d` / `--delay` | Delay entre tentativas (s) | 1.0 |
| `-o` / `--output-dir` | Diretório de saída | `bruteforce_results/` |
| `--smart` | Ativa geração de variações | desativado |

---

## Output Geral do Script

| Arquivo | Formato | Conteúdo |
|---|---|---|
| `bruteforce_<user>_<ts>.json` | JSON | Alvo, configuração, estatísticas, últimas 100 tentativas |
| `ticket_<user>_<ts>.txt` | Texto | Saída do `klist` pós-autenticação |
| `krb5cc_<user>_<ts>` | Binário | Cópia do credential cache Kerberos |

O terminal exibe progresso em tempo real (tentativas, taxa, senha testada) e, em caso de sucesso, as credenciais encontradas em destaque.

---

## Dependências

- `kinit` (MIT Kerberos ou Heimdal)
- `colorama` (`pip install colorama`)
- Bibliotecas padrão: `subprocess`, `threading`, `queue`, `argparse`, `json`
